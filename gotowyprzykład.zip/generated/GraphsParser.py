# Generated from generated/Graphs.g4 by ANTLR 4.13.0
# encoding: utf-8
from antlr4 import *
from io import StringIO
import sys
if sys.version_info[1] > 5:
	from typing import TextIO
else:
	from typing.io import TextIO

def serializedATN():
    return [
        4,1,13,133,2,0,7,0,2,1,7,1,2,2,7,2,2,3,7,3,2,4,7,4,2,5,7,5,2,6,7,
        6,2,7,7,7,2,8,7,8,2,9,7,9,2,10,7,10,2,11,7,11,2,12,7,12,2,13,7,13,
        2,14,7,14,2,15,7,15,2,16,7,16,2,17,7,17,2,18,7,18,1,0,1,0,1,0,1,
        0,1,0,1,0,3,0,45,8,0,1,1,1,1,1,1,1,1,1,1,1,1,3,1,53,8,1,1,2,1,2,
        1,2,1,3,1,3,3,3,60,8,3,1,4,1,4,1,4,1,4,3,4,66,8,4,1,5,1,5,1,5,1,
        5,1,5,1,5,1,5,1,5,1,5,1,5,3,5,78,8,5,1,6,1,6,1,6,1,6,1,7,1,7,1,7,
        1,7,1,8,1,8,1,8,1,8,1,9,1,9,1,9,3,9,95,8,9,1,10,1,10,1,10,1,11,1,
        11,1,11,1,12,1,12,1,12,1,12,1,13,1,13,1,13,1,13,1,13,5,13,112,8,
        13,10,13,12,13,115,9,13,1,13,1,13,1,14,1,14,3,14,121,8,14,1,15,1,
        15,3,15,125,8,15,1,16,1,16,1,17,1,17,1,18,1,18,1,18,0,0,19,0,2,4,
        6,8,10,12,14,16,18,20,22,24,26,28,30,32,34,36,0,0,124,0,44,1,0,0,
        0,2,52,1,0,0,0,4,54,1,0,0,0,6,59,1,0,0,0,8,65,1,0,0,0,10,77,1,0,
        0,0,12,79,1,0,0,0,14,83,1,0,0,0,16,87,1,0,0,0,18,94,1,0,0,0,20,96,
        1,0,0,0,22,99,1,0,0,0,24,102,1,0,0,0,26,106,1,0,0,0,28,120,1,0,0,
        0,30,124,1,0,0,0,32,126,1,0,0,0,34,128,1,0,0,0,36,130,1,0,0,0,38,
        39,3,16,8,0,39,40,3,4,2,0,40,41,3,32,16,0,41,42,3,2,1,0,42,45,1,
        0,0,0,43,45,1,0,0,0,44,38,1,0,0,0,44,43,1,0,0,0,45,1,1,0,0,0,46,
        47,3,16,8,0,47,48,3,4,2,0,48,49,3,32,16,0,49,50,3,2,1,0,50,53,1,
        0,0,0,51,53,1,0,0,0,52,46,1,0,0,0,52,51,1,0,0,0,53,3,1,0,0,0,54,
        55,3,8,4,0,55,56,3,6,3,0,56,5,1,0,0,0,57,60,3,10,5,0,58,60,1,0,0,
        0,59,57,1,0,0,0,59,58,1,0,0,0,60,7,1,0,0,0,61,62,3,20,10,0,62,63,
        3,8,4,0,63,66,1,0,0,0,64,66,1,0,0,0,65,61,1,0,0,0,65,64,1,0,0,0,
        66,9,1,0,0,0,67,68,3,20,10,0,68,69,3,10,5,0,69,78,1,0,0,0,70,71,
        3,12,6,0,71,72,3,10,5,0,72,78,1,0,0,0,73,74,3,14,7,0,74,75,3,10,
        5,0,75,78,1,0,0,0,76,78,1,0,0,0,77,67,1,0,0,0,77,70,1,0,0,0,77,73,
        1,0,0,0,77,76,1,0,0,0,78,11,1,0,0,0,79,80,3,22,11,0,80,81,3,26,13,
        0,81,82,5,1,0,0,82,13,1,0,0,0,83,84,3,24,12,0,84,85,3,26,13,0,85,
        86,5,1,0,0,86,15,1,0,0,0,87,88,5,2,0,0,88,89,3,34,17,0,89,90,3,18,
        9,0,90,17,1,0,0,0,91,92,5,3,0,0,92,95,3,34,17,0,93,95,1,0,0,0,94,
        91,1,0,0,0,94,93,1,0,0,0,95,19,1,0,0,0,96,97,5,4,0,0,97,98,3,34,
        17,0,98,21,1,0,0,0,99,100,5,5,0,0,100,101,3,34,17,0,101,23,1,0,0,
        0,102,103,5,6,0,0,103,104,3,30,15,0,104,105,3,30,15,0,105,25,1,0,
        0,0,106,113,5,7,0,0,107,108,3,34,17,0,108,109,5,8,0,0,109,110,3,
        28,14,0,110,112,1,0,0,0,111,107,1,0,0,0,112,115,1,0,0,0,113,111,
        1,0,0,0,113,114,1,0,0,0,114,116,1,0,0,0,115,113,1,0,0,0,116,117,
        5,9,0,0,117,27,1,0,0,0,118,121,3,36,18,0,119,121,3,34,17,0,120,118,
        1,0,0,0,120,119,1,0,0,0,121,29,1,0,0,0,122,125,5,10,0,0,123,125,
        3,34,17,0,124,122,1,0,0,0,124,123,1,0,0,0,125,31,1,0,0,0,126,127,
        5,1,0,0,127,33,1,0,0,0,128,129,5,11,0,0,129,35,1,0,0,0,130,131,5,
        12,0,0,131,37,1,0,0,0,9,44,52,59,65,77,94,113,120,124
    ]

class GraphsParser ( Parser ):

    grammarFileName = "Graphs.g4"

    atn = ATNDeserializer().deserialize(serializedATN())

    decisionsToDFA = [ DFA(ds, i) for i, ds in enumerate(atn.decisionToState) ]

    sharedContextCache = PredictionContextCache()

    literalNames = [ "<INVALID>", "'end'", "'graph'", "'extends'", "'add node'", 
                     "'modify'", "'set edge'", "'['", "':'", "']'", "'*'" ]

    symbolicNames = [ "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "ID", "INT", 
                      "White_spaces" ]

    RULE_s = 0
    RULE_g = 1
    RULE_a = 2
    RULE_aa = 3
    RULE_w = 4
    RULE_k = 5
    RULE_m = 6
    RULE_e = 7
    RULE_graph = 8
    RULE_extend = 9
    RULE_node = 10
    RULE_modify = 11
    RULE_edge = 12
    RULE_attributes = 13
    RULE_value = 14
    RULE_dest_node = 15
    RULE_end_graph = 16
    RULE_name = 17
    RULE_number = 18

    ruleNames =  [ "s", "g", "a", "aa", "w", "k", "m", "e", "graph", "extend", 
                   "node", "modify", "edge", "attributes", "value", "dest_node", 
                   "end_graph", "name", "number" ]

    EOF = Token.EOF
    T__0=1
    T__1=2
    T__2=3
    T__3=4
    T__4=5
    T__5=6
    T__6=7
    T__7=8
    T__8=9
    T__9=10
    ID=11
    INT=12
    White_spaces=13

    def __init__(self, input:TokenStream, output:TextIO = sys.stdout):
        super().__init__(input, output)
        self.checkVersion("4.13.0")
        self._interp = ParserATNSimulator(self, self.atn, self.decisionsToDFA, self.sharedContextCache)
        self._predicates = None




    class SContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def graph(self):
            return self.getTypedRuleContext(GraphsParser.GraphContext,0)


        def a(self):
            return self.getTypedRuleContext(GraphsParser.AContext,0)


        def end_graph(self):
            return self.getTypedRuleContext(GraphsParser.End_graphContext,0)


        def g(self):
            return self.getTypedRuleContext(GraphsParser.GContext,0)


        def getRuleIndex(self):
            return GraphsParser.RULE_s

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitS" ):
                return visitor.visitS(self)
            else:
                return visitor.visitChildren(self)




    def s(self):

        localctx = GraphsParser.SContext(self, self._ctx, self.state)
        self.enterRule(localctx, 0, self.RULE_s)
        try:
            self.state = 44
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [2]:
                self.enterOuterAlt(localctx, 1)
                self.state = 38
                self.graph()
                self.state = 39
                self.a()
                self.state = 40
                self.end_graph()
                self.state = 41
                self.g()
                pass
            elif token in [-1]:
                self.enterOuterAlt(localctx, 2)

                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class GContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def graph(self):
            return self.getTypedRuleContext(GraphsParser.GraphContext,0)


        def a(self):
            return self.getTypedRuleContext(GraphsParser.AContext,0)


        def end_graph(self):
            return self.getTypedRuleContext(GraphsParser.End_graphContext,0)


        def g(self):
            return self.getTypedRuleContext(GraphsParser.GContext,0)


        def getRuleIndex(self):
            return GraphsParser.RULE_g

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitG" ):
                return visitor.visitG(self)
            else:
                return visitor.visitChildren(self)




    def g(self):

        localctx = GraphsParser.GContext(self, self._ctx, self.state)
        self.enterRule(localctx, 2, self.RULE_g)
        try:
            self.state = 52
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [2]:
                self.enterOuterAlt(localctx, 1)
                self.state = 46
                self.graph()
                self.state = 47
                self.a()
                self.state = 48
                self.end_graph()
                self.state = 49
                self.g()
                pass
            elif token in [-1]:
                self.enterOuterAlt(localctx, 2)

                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class AContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def w(self):
            return self.getTypedRuleContext(GraphsParser.WContext,0)


        def aa(self):
            return self.getTypedRuleContext(GraphsParser.AaContext,0)


        def getRuleIndex(self):
            return GraphsParser.RULE_a

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitA" ):
                return visitor.visitA(self)
            else:
                return visitor.visitChildren(self)




    def a(self):

        localctx = GraphsParser.AContext(self, self._ctx, self.state)
        self.enterRule(localctx, 4, self.RULE_a)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 54
            self.w()
            self.state = 55
            self.aa()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class AaContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def k(self):
            return self.getTypedRuleContext(GraphsParser.KContext,0)


        def getRuleIndex(self):
            return GraphsParser.RULE_aa

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitAa" ):
                return visitor.visitAa(self)
            else:
                return visitor.visitChildren(self)




    def aa(self):

        localctx = GraphsParser.AaContext(self, self._ctx, self.state)
        self.enterRule(localctx, 6, self.RULE_aa)
        try:
            self.state = 59
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,2,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 57
                self.k()
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)

                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class WContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def node(self):
            return self.getTypedRuleContext(GraphsParser.NodeContext,0)


        def w(self):
            return self.getTypedRuleContext(GraphsParser.WContext,0)


        def getRuleIndex(self):
            return GraphsParser.RULE_w

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitW" ):
                return visitor.visitW(self)
            else:
                return visitor.visitChildren(self)




    def w(self):

        localctx = GraphsParser.WContext(self, self._ctx, self.state)
        self.enterRule(localctx, 8, self.RULE_w)
        try:
            self.state = 65
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,3,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 61
                self.node()
                self.state = 62
                self.w()
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)

                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class KContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def node(self):
            return self.getTypedRuleContext(GraphsParser.NodeContext,0)


        def k(self):
            return self.getTypedRuleContext(GraphsParser.KContext,0)


        def m(self):
            return self.getTypedRuleContext(GraphsParser.MContext,0)


        def e(self):
            return self.getTypedRuleContext(GraphsParser.EContext,0)


        def getRuleIndex(self):
            return GraphsParser.RULE_k

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitK" ):
                return visitor.visitK(self)
            else:
                return visitor.visitChildren(self)




    def k(self):

        localctx = GraphsParser.KContext(self, self._ctx, self.state)
        self.enterRule(localctx, 10, self.RULE_k)
        try:
            self.state = 77
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [4]:
                self.enterOuterAlt(localctx, 1)
                self.state = 67
                self.node()
                self.state = 68
                self.k()
                pass
            elif token in [5]:
                self.enterOuterAlt(localctx, 2)
                self.state = 70
                self.m()
                self.state = 71
                self.k()
                pass
            elif token in [6]:
                self.enterOuterAlt(localctx, 3)
                self.state = 73
                self.e()
                self.state = 74
                self.k()
                pass
            elif token in [1]:
                self.enterOuterAlt(localctx, 4)

                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class MContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def modify(self):
            return self.getTypedRuleContext(GraphsParser.ModifyContext,0)


        def attributes(self):
            return self.getTypedRuleContext(GraphsParser.AttributesContext,0)


        def getRuleIndex(self):
            return GraphsParser.RULE_m

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitM" ):
                return visitor.visitM(self)
            else:
                return visitor.visitChildren(self)




    def m(self):

        localctx = GraphsParser.MContext(self, self._ctx, self.state)
        self.enterRule(localctx, 12, self.RULE_m)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 79
            self.modify()
            self.state = 80
            self.attributes()
            self.state = 81
            self.match(GraphsParser.T__0)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class EContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def edge(self):
            return self.getTypedRuleContext(GraphsParser.EdgeContext,0)


        def attributes(self):
            return self.getTypedRuleContext(GraphsParser.AttributesContext,0)


        def getRuleIndex(self):
            return GraphsParser.RULE_e

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitE" ):
                return visitor.visitE(self)
            else:
                return visitor.visitChildren(self)




    def e(self):

        localctx = GraphsParser.EContext(self, self._ctx, self.state)
        self.enterRule(localctx, 14, self.RULE_e)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 83
            self.edge()
            self.state = 84
            self.attributes()
            self.state = 85
            self.match(GraphsParser.T__0)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class GraphContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def name(self):
            return self.getTypedRuleContext(GraphsParser.NameContext,0)


        def extend(self):
            return self.getTypedRuleContext(GraphsParser.ExtendContext,0)


        def getRuleIndex(self):
            return GraphsParser.RULE_graph

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitGraph" ):
                return visitor.visitGraph(self)
            else:
                return visitor.visitChildren(self)




    def graph(self):

        localctx = GraphsParser.GraphContext(self, self._ctx, self.state)
        self.enterRule(localctx, 16, self.RULE_graph)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 87
            self.match(GraphsParser.T__1)
            self.state = 88
            self.name()
            self.state = 89
            self.extend()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ExtendContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def name(self):
            return self.getTypedRuleContext(GraphsParser.NameContext,0)


        def getRuleIndex(self):
            return GraphsParser.RULE_extend

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitExtend" ):
                return visitor.visitExtend(self)
            else:
                return visitor.visitChildren(self)




    def extend(self):

        localctx = GraphsParser.ExtendContext(self, self._ctx, self.state)
        self.enterRule(localctx, 18, self.RULE_extend)
        try:
            self.state = 94
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [3]:
                self.enterOuterAlt(localctx, 1)
                self.state = 91
                self.match(GraphsParser.T__2)
                self.state = 92
                self.name()
                pass
            elif token in [1, 4, 5, 6]:
                self.enterOuterAlt(localctx, 2)

                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class NodeContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def name(self):
            return self.getTypedRuleContext(GraphsParser.NameContext,0)


        def getRuleIndex(self):
            return GraphsParser.RULE_node

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitNode" ):
                return visitor.visitNode(self)
            else:
                return visitor.visitChildren(self)




    def node(self):

        localctx = GraphsParser.NodeContext(self, self._ctx, self.state)
        self.enterRule(localctx, 20, self.RULE_node)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 96
            self.match(GraphsParser.T__3)
            self.state = 97
            self.name()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ModifyContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def name(self):
            return self.getTypedRuleContext(GraphsParser.NameContext,0)


        def getRuleIndex(self):
            return GraphsParser.RULE_modify

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitModify" ):
                return visitor.visitModify(self)
            else:
                return visitor.visitChildren(self)




    def modify(self):

        localctx = GraphsParser.ModifyContext(self, self._ctx, self.state)
        self.enterRule(localctx, 22, self.RULE_modify)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 99
            self.match(GraphsParser.T__4)
            self.state = 100
            self.name()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class EdgeContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def dest_node(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(GraphsParser.Dest_nodeContext)
            else:
                return self.getTypedRuleContext(GraphsParser.Dest_nodeContext,i)


        def getRuleIndex(self):
            return GraphsParser.RULE_edge

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitEdge" ):
                return visitor.visitEdge(self)
            else:
                return visitor.visitChildren(self)




    def edge(self):

        localctx = GraphsParser.EdgeContext(self, self._ctx, self.state)
        self.enterRule(localctx, 24, self.RULE_edge)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 102
            self.match(GraphsParser.T__5)
            self.state = 103
            self.dest_node()
            self.state = 104
            self.dest_node()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class AttributesContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def name(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(GraphsParser.NameContext)
            else:
                return self.getTypedRuleContext(GraphsParser.NameContext,i)


        def value(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(GraphsParser.ValueContext)
            else:
                return self.getTypedRuleContext(GraphsParser.ValueContext,i)


        def getRuleIndex(self):
            return GraphsParser.RULE_attributes

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitAttributes" ):
                return visitor.visitAttributes(self)
            else:
                return visitor.visitChildren(self)




    def attributes(self):

        localctx = GraphsParser.AttributesContext(self, self._ctx, self.state)
        self.enterRule(localctx, 26, self.RULE_attributes)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 106
            self.match(GraphsParser.T__6)
            self.state = 113
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==11:
                self.state = 107
                self.name()
                self.state = 108
                self.match(GraphsParser.T__7)
                self.state = 109
                self.value()
                self.state = 115
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 116
            self.match(GraphsParser.T__8)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ValueContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def number(self):
            return self.getTypedRuleContext(GraphsParser.NumberContext,0)


        def name(self):
            return self.getTypedRuleContext(GraphsParser.NameContext,0)


        def getRuleIndex(self):
            return GraphsParser.RULE_value

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitValue" ):
                return visitor.visitValue(self)
            else:
                return visitor.visitChildren(self)




    def value(self):

        localctx = GraphsParser.ValueContext(self, self._ctx, self.state)
        self.enterRule(localctx, 28, self.RULE_value)
        try:
            self.state = 120
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [12]:
                self.enterOuterAlt(localctx, 1)
                self.state = 118
                self.number()
                pass
            elif token in [11]:
                self.enterOuterAlt(localctx, 2)
                self.state = 119
                self.name()
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Dest_nodeContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def name(self):
            return self.getTypedRuleContext(GraphsParser.NameContext,0)


        def getRuleIndex(self):
            return GraphsParser.RULE_dest_node

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitDest_node" ):
                return visitor.visitDest_node(self)
            else:
                return visitor.visitChildren(self)




    def dest_node(self):

        localctx = GraphsParser.Dest_nodeContext(self, self._ctx, self.state)
        self.enterRule(localctx, 30, self.RULE_dest_node)
        try:
            self.state = 124
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [10]:
                self.enterOuterAlt(localctx, 1)
                self.state = 122
                self.match(GraphsParser.T__9)
                pass
            elif token in [11]:
                self.enterOuterAlt(localctx, 2)
                self.state = 123
                self.name()
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class End_graphContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return GraphsParser.RULE_end_graph

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitEnd_graph" ):
                return visitor.visitEnd_graph(self)
            else:
                return visitor.visitChildren(self)




    def end_graph(self):

        localctx = GraphsParser.End_graphContext(self, self._ctx, self.state)
        self.enterRule(localctx, 32, self.RULE_end_graph)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 126
            self.match(GraphsParser.T__0)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class NameContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ID(self):
            return self.getToken(GraphsParser.ID, 0)

        def getRuleIndex(self):
            return GraphsParser.RULE_name

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitName" ):
                return visitor.visitName(self)
            else:
                return visitor.visitChildren(self)




    def name(self):

        localctx = GraphsParser.NameContext(self, self._ctx, self.state)
        self.enterRule(localctx, 34, self.RULE_name)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 128
            self.match(GraphsParser.ID)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class NumberContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def INT(self):
            return self.getToken(GraphsParser.INT, 0)

        def getRuleIndex(self):
            return GraphsParser.RULE_number

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitNumber" ):
                return visitor.visitNumber(self)
            else:
                return visitor.visitChildren(self)




    def number(self):

        localctx = GraphsParser.NumberContext(self, self._ctx, self.state)
        self.enterRule(localctx, 36, self.RULE_number)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 130
            self.match(GraphsParser.INT)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx





